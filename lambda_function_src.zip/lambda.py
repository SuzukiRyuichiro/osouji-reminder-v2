import json


def lambda_handler(event, context)
  print("hey")
  return event['key1']
